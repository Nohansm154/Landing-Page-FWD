## FWD  Front End Web Development Nanodegree
Landing Project Manipulating the DOM  - Due 23 / 2 / 2022
Version 2  - 8 / 3 /2022
Email : nohansm11@gmail.com
        ghais1617@gmail.com

## The target of the project
implementing the DOM with JavaScript

## Languages used
HTML
CSS
JavaScript

## software used
Atom

## List Of Files
index.html / styles.css / app.js / README.md

## The program functionalities are

- Adding dynamic navigation list items on adding a new section to a page
- Scrolling smoothly

## Most used resources
Udacity tutorials
W3school tutorials
