/**
 *
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 *
 * Dependencies: None
 *
 * JS Version: ES2015/ES6
 *
 * JS Standard: ESlint
 *
 */

/**
 * Comments should be present at the beginning of each procedure and class.
 * Great to have comments before crucial code sections within the procedure.
 */

/**
  *Copy the required classes and ids from HTML
  *<nav class="navbar__menu">
  *<ul id="navbar__list">
  *<section id="section1" data-nav="Section 1" class="your-active-class">

*/
// Define Global Variables using DOM and arrays
const MyNaviBar = document.getElementById("navbar__list");
const sections = document.querySelectorAll("section");
var selected = "";


// build the navigation bar using objects ,DOM and loops
function NavibarItems() {
    for (item of sections) {
        MyListItem = document.createElement("li");
        MyListItem.innerHTML = `<li><a href="#${item.id}" data-nav="${item.id}" class="menu__link">${item.dataset.nav}</a>`;
        MyNaviBar.appendChild(MyListItem);
    }
}
NavibarItems();
// Add class 'active' to section when it's close to viewport
//Styling the active class.

window.onscroll = function() {
    document.querySelectorAll("section").forEach(function(activeSection) {
        if (activeSection.getBoundingClientRect().top >= -400 &&

            activeSection.getBoundingClientRect().top <= 150) {

            activeSection.classList.add("your-active-class");

            selected = activeSection.getAttribute("id");

            // check the active link

            const activeLink = document.querySelector(`a[data-nav='${selected}']`);

            // get any link that has activeli class and the data-nav value is not equal to active section id

            const notActiveLinks = document.querySelectorAll(`a.activeli:not([data-nav='${selected}'])`);

            notActiveLinks.forEach((notActive) => {

                // remove all inactive links

                notActive.classList.remove("activeli");

            })

            activeLink.classList.add("activeli");
        } else {

            activeSection.classList.remove("your-active-class");

        }

        // Navigating smoothly to the specific section

        MyNaviBar.addEventListener('click', function(smoothly) {

            smoothly.preventDefault();
            const target = smoothly.target;
            if (selected = target.getAttribute('href')) {
                const SecId = target.getAttribute('href').slice(1);
                document.getElementById(SecId).scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });

};
